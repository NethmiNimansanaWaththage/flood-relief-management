<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flood Relief System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="style.css">

    
</head>

<body>
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-0 custom-navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php"style="font-size:25px;">HOME</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <?php if ($_SESSION['role'] == 'user'): ?>
                            <li class="nav-item"><a class="nav-link" href="relief-request.php"style="font-size:21px;">Submit Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="my-requests.php"style="font-size:21px;">My Requests</a></li>
                        <?php elseif ($_SESSION['role'] == 'admin'): ?>
                            <li class="nav-item"><a class="nav-link " href="admin-users.php" style="font-size:21px;">Manage Users</a></li>
                            <li class="nav-item"><a class="nav-link" href="admin-reports.php"style="font-size:21px;">Reports</a></li>
                        <?php endif; ?>
                        <li class="nav-item"><a class="nav-link" href="logout.php"style="font-size:20px;">Logout (<?php echo $_SESSION['email'] ?? 'User'; ?>)</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link text-light; fw-light" href="login.php"style="font-size:21px;">Login</a></li>
                        <li class="nav-item"><a class="nav-link text-light fw-light" href="user-Register.php"style="font-size:21px;">Register as User</a></li>
                        <li class="nav-item"><a class="nav-link text-light fw-light" href="admin-Register.php"style="font-size:21px;">Register as Admin</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>


    <style>
   
    .custom-navbar {
        width: 100%;
        max-width: 100%;
        padding-left: 2rem;
        padding-right: 2rem;
        height: 75px;
        border-bottom: 5px solid #ffffff;
        border-top: none;  
    }

  
    .navbar-nav .nav-link.fw-light {
        color: #f0f4e8 !important; 
        
    }

    
    .navbar-nav .nav-link.fw-light:hover {
        color: #ffffff !important;
    }
</style>
    <div class="container">

        <?php
        if (isset($_SESSION['success'])) {
            echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
            unset($_SESSION['success']);
        }
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>