<?php
session_start();
require_once("db_connect.php");

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}


$filter_district = $_GET['district'] ?? '';
$filter_relief = $_GET['relief_type'] ?? '';
$filter_severity = $_GET['severity'] ?? '';


$where = "WHERE 1=1";
if($filter_district) {
    $where .= " AND district = '$filter_district'";
}
if($filter_relief) {
    $where .= " AND relief_type = '$filter_relief'";
}
if($filter_severity) {
    $where .= " AND severity = '$filter_severity'";
}


$total_users_sql = "SELECT COUNT(*) as total FROM Users";
$total_requests_sql = "SELECT COUNT(*) as total FROM Relief_requests $where";
$high_severity_sql = "SELECT COUNT(*) as total FROM Relief_requests WHERE severity = 'High'";
$food_requests_sql = "SELECT COUNT(*) as total FROM Relief_requests WHERE relief_type = 'food'";
$medicine_requests_sql = "SELECT COUNT(*) as total FROM Relief_requests WHERE relief_type = 'medicine'";

$total_users = mysqli_fetch_assoc(mysqli_query($conn, $total_users_sql))['total'];
$total_requests = mysqli_fetch_assoc(mysqli_query($conn, $total_requests_sql))['total'];
$high_severity = mysqli_fetch_assoc(mysqli_query($conn, $high_severity_sql))['total'];
$food_requests = mysqli_fetch_assoc(mysqli_query($conn, $food_requests_sql))['total'];
$medicine_requests = mysqli_fetch_assoc(mysqli_query($conn, $medicine_requests_sql))['total'];


$requests_sql = "SELECT r.*, u.fullname, u.contact_number FROM Relief_requests r 
                 LEFT JOIN Users u ON r.user_id = u.user_id 
                 $where ORDER BY r.request_id DESC";
$requests_result = mysqli_query($conn, $requests_sql);
?>

<?php include_once("header.php"); ?>

<h2>System Reports (Admin)</h2>

<div style="background: #e9ffe9; padding: 15px; margin: 20px 0; border-radius: 5px;">
    <h3>Summary Statistics</h3>
    <p>Total Registered Users: <strong><?php echo $total_users; ?></strong></p>
    <p>Total Relief Requests: <strong><?php echo $total_requests; ?></strong></p>
    <p>High Severity Households: <strong><?php echo $high_severity; ?></strong></p>
    <p>Food Requests: <strong><?php echo $food_requests; ?></strong></p>
    <p>Medicine Requests: <strong><?php echo $medicine_requests; ?></strong></p>
</div>

<h3>Filter Reports</h3>
<form method="get" action="">
    <label>District:</label>
    <select name="district">
        <option value="">All Districts</option>
        <option value="Colombo" <?php echo ($filter_district == 'Colombo') ? 'selected' : ''; ?>>Colombo</option>
        <option value="Gampaha" <?php echo ($filter_district == 'Gampaha') ? 'selected' : ''; ?>>Gampaha</option>
        <option value="Kalutara" <?php echo ($filter_district == 'Kalutara') ? 'selected' : ''; ?>>Kalutara</option>
        <option value="Kandy" <?php echo ($filter_district == 'Kandy') ? 'selected' : ''; ?>>Kandy</option>
    </select>
    
    <label>Relief Type:</label>
   