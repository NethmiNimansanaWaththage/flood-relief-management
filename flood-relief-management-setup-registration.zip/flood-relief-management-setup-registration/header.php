<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flood Relief System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  
</head>
<body>
    <nav>
        <a href="index.php">Home</a>
        
        <?php if(isset($_SESSION['user_id'])): ?>
            <?php if($_SESSION['role'] == 'user'): ?>
                <a href="relief-request.php">Submit Request</a>
                <a href="my-requests.php">My Requests</a>
            <?php elseif($_SESSION['role'] == 'admin'): ?>
                <a href="admin-users.php">Manage Users</a>
                <a href="admin-reports.php">Reports</a>
            <?php endif; ?>
            <a href="logout.php">Logout (<?php echo $_SESSION['email'] ?? 'User'; ?>)</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="user-Register.php">Register as User</a>
            <a href="admin-Register.php">Register as Admin</a>
        <?php endif; ?>
    </nav>
    
    <div class="container">
        <?php
        // Display alerts
        if(isset($_SESSION['success'])) {
            echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
            unset($_SESSION['success']);
        }
        if(isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>