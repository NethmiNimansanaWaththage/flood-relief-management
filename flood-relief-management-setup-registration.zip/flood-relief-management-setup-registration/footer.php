    </div>

    <script>
        function showAlert(message, type = 'success') {
            alert(message);
        }

        function confirmAction(message) {
            return confirm(message);
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>

    </html>