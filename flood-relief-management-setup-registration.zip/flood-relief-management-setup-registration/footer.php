    </div>
    
    <script>
    // Simple JavaScript for popup messages
    function showAlert(message, type = 'success') {
        alert(message);
    }
    
    function confirmAction(message) {
        return confirm(message);
    }
    </script>
</body>
</html>