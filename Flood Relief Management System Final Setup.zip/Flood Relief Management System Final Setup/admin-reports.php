<?php
session_start();
require_once("db_connect.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$filter_district = isset($_GET['district']) ? $_GET['district'] : '';
$filter_relief = isset($_GET['relief_type']) ? $_GET['relief_type'] : '';
$filter_severity = isset($_GET['severity']) ? $_GET['severity'] : '';

$where = "WHERE 1=1";

if (!empty($filter_district)) {
    $filter_district = mysqli_real_escape_string($conn, $filter_district);
    $where .= " AND r.district = '$filter_district'";
}
if (!empty($filter_relief)) {
    $filter_relief = mysqli_real_escape_string($conn, $filter_relief);
    $where .= " AND r.relief_type = '$filter_relief'";
}
if (!empty($filter_severity)) {
    $filter_severity = mysqli_real_escape_string($conn, $filter_severity);
    $where .= " AND r.severity = '$filter_severity'";
}

$total_users_sql = "SELECT COUNT(*) as total FROM Users";
$total_users_result = mysqli_query($conn, $total_users_sql);
$total_users = 0;
if ($total_users_result) {
    $total_users = mysqli_fetch_assoc($total_users_result)['total'];
}

$total_requests_sql = "SELECT COUNT(*) as total FROM Relief_requests r $where";
$total_requests_result = mysqli_query($conn, $total_requests_sql);
$total_requests = 0;
if ($total_requests_result) {
    $total_requests = mysqli_fetch_assoc($total_requests_result)['total'];
}

$high_severity_sql = "SELECT COUNT(*) as total FROM Relief_requests r $where AND r.severity = 'High'";
$high_severity_result = mysqli_query($conn, $high_severity_sql);
$high_severity = 0;
if ($high_severity_result) {
    $high_severity = mysqli_fetch_assoc($high_severity_result)['total'];
}

$food_requests_sql = "SELECT COUNT(*) as total FROM Relief_requests r $where AND r.relief_type = 'food'";
$food_requests_result = mysqli_query($conn, $food_requests_sql);
$food_requests = 0;
if ($food_requests_result) {
    $food_requests = mysqli_fetch_assoc($food_requests_result)['total'];
}

$medicine_requests_sql = "SELECT COUNT(*) as total FROM Relief_requests r $where AND r.relief_type = 'medicine'";
$medicine_requests_result = mysqli_query($conn, $medicine_requests_sql);
$medicine_requests = 0;
if ($medicine_requests_result) {
    $medicine_requests = mysqli_fetch_assoc($medicine_requests_result)['total'];
}

$water_requests_sql = "SELECT COUNT(*) as total FROM Relief_requests r $where AND r.relief_type = 'water'";
$water_requests_result = mysqli_query($conn, $water_requests_sql);
$water_requests = 0;
if ($water_requests_result) {
    $water_requests = mysqli_fetch_assoc($water_requests_result)['total'];
}

$shelter_requests_sql = "SELECT COUNT(*) as total FROM Relief_requests r $where AND r.relief_type = 'shelter'";
$shelter_requests_result = mysqli_query($conn, $shelter_requests_sql);
$shelter_requests = 0;
if ($shelter_requests_result) {
    $shelter_requests = mysqli_fetch_assoc($shelter_requests_result)['total'];
}

$requests_sql = "SELECT r.*, u.fullname, u.contact, u.Email 
                 FROM Relief_requests r 
                 LEFT JOIN Users u ON r.user_id = u.user_id 
                 $where 
                 ORDER BY r.request_id DESC";

$requests_result = mysqli_query($conn, $requests_sql);

if (!$requests_result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<?php include_once("header.php"); ?>

<h2>System Reports (Admin)</h2>

<!-- Summary Statistics -->
<div style="background: #e9ffe9; padding: 15px; margin: 20px 0; border-radius: 5px;">
    <h3>Summary Statistics</h3>
    <p>Total Registered Users: <strong><?php echo $total_users; ?></strong></p>
    <p>Total Relief Requests: <strong><?php echo $total_requests; ?></strong></p>
    <p>High Severity Households: <strong><?php echo $high_severity; ?></strong></p>
    <p>Food Requests: <strong><?php echo $food_requests; ?></strong></p>
    <p>Medicine Requests: <strong><?php echo $medicine_requests; ?></strong></p>
    <p>Water Requests: <strong><?php echo $water_requests; ?></strong></p>
    <p>Shelter Requests: <strong><?php echo $shelter_requests; ?></strong></p>
</div>

<!-- Filter Form -->
<h3>Filter Reports</h3>
<form method="get" action="">
    <label>District:</label>
    <select name="district">
        <option value="">All Districts</option>
        <option value="Colombo" <?php echo ($filter_district == 'Colombo') ? 'selected' : ''; ?>>Colombo</option>
        <option value="Gampaha" <?php echo ($filter_district == 'Gampaha') ? 'selected' : ''; ?>>Gampaha</option>
        <option value="Kalutara" <?php echo ($filter_district == 'Kalutara') ? 'selected' : ''; ?>>Kalutara</option>
        <option value="Kandy" <?php echo ($filter_district == 'Kandy') ? 'selected' : ''; ?>>Kandy</option>
        <option value="Matale" <?php echo ($filter_district == 'Matale') ? 'selected' : ''; ?>>Matale</option>
        <option value="Nuwara Eliya" <?php echo ($filter_district == 'Nuwara Eliya') ? 'selected' : ''; ?>>Nuwara Eliya</option>
        <option value="Galle" <?php echo ($filter_district == 'Galle') ? 'selected' : ''; ?>>Galle</option>
        <option value="Matara" <?php echo ($filter_district == 'Matara') ? 'selected' : ''; ?>>Matara</option>
        <option value="Hambantota" <?php echo ($filter_district == 'Hambantota') ? 'selected' : ''; ?>>Hambantota</option>
        <option value="Jaffna" <?php echo ($filter_district == 'Jaffna') ? 'selected' : ''; ?>>Jaffna</option>
    </select>

    <label>Severity:</label>
    <select name="severity">
        <option value="">All Severities</option>
        <option value="Low" <?php echo ($filter_severity == 'Low') ? 'selected' : ''; ?>>Low</option>
        <option value="Medium" <?php echo ($filter_severity == 'Medium') ? 'selected' : ''; ?>>Medium</option>
        <option value="High" <?php echo ($filter_severity == 'High') ? 'selected' : ''; ?>>High</option>
    </select>

    <label>Relief Type:</label>
    <select name="relief_type">
        <option value="">All Types</option>
        <option value="food" <?php echo ($filter_relief == 'food') ? 'selected' : ''; ?>>Food</option>
        <option value="water" <?php echo ($filter_relief == 'water') ? 'selected' : ''; ?>>Water</option>
        <option value="medicine" <?php echo ($filter_relief == 'medicine') ? 'selected' : ''; ?>>Medicine</option>
        <option value="shelter" <?php echo ($filter_relief == 'shelter') ? 'selected' : ''; ?>>Shelter</option>
    </select>

    <button type="submit">Apply Filters</button>
</form>

<a href="admin-reports.php">Clear All Filters</a><br><br>

<!-- Filtered Requests Table -->
<h3>Filtered Requests</h3>
<?php if ($requests_result && mysqli_num_rows($requests_result) > 0): ?>
    <table class="table table-bordered">
        <tr>
            <th>Request ID</th>
            <th>User</th>
            <th>Contact</th>
            <th>Relief Type</th>
            <th>District</th>
            <th>Severity</th>
            <th>Description</th>
        </tr>
        <?php while ($request = mysqli_fetch_assoc($requests_result)): ?>
            <tr>
                <td><?php echo $request['request_id']; ?></td>
                <td><?php echo htmlspecialchars($request['fullname']); ?></td>
                <td><?php echo htmlspecialchars($request['contact']); ?></td>
                <td><?php echo ucfirst($request['relief_type']); ?></td>
                <td><?php echo htmlspecialchars($request['district']); ?></td>
                <td>
                    <span style="color: <?php
                                        if ($request['severity'] == 'High') echo 'red';
                                        elseif ($request['severity'] == 'Medium') echo 'orange';
                                        else echo 'green';
                                        ?>">
                        <?php echo $request['severity']; ?>
                    </span>
                </td>
                <td><?php echo htmlspecialchars(substr($request['description'], 0, 50)) . '...'; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>No requests found with current filters.</p>
    <?php if ($requests_result === false): ?>
        <p style="color: red;">Database error: <?php echo mysqli_error($conn); ?></p>
    <?php endif; ?>
<?php endif; ?>

<?php include_once("footer.php"); ?>